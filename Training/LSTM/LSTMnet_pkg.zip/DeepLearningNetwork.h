//
// File: DeepLearningNetwork.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Sep-2021 16:49:07
//

#ifndef DEEPLEARNINGNETWORK_H
#define DEEPLEARNINGNETWORK_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
class net2lstm_miladch235_netWork0_0;

// Function Declarations
namespace coder {
void DeepLearningNetwork_setup(net2lstm_miladch235_netWork0_0 *obj);

}

#endif
//
// File trailer for DeepLearningNetwork.h
//
// [EOF]
//
