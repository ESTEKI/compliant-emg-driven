//
// File: LSTMnet_initialize.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Sep-2021 16:49:07
//

// Include Files
#include "LSTMnet_initialize.h"
#include "LSTMnet.h"
#include "LSTMnet_data.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void LSTMnet_initialize()
{
  LSTMnet_init();
  isInitialized_LSTMnet = true;
}

//
// File trailer for LSTMnet_initialize.cpp
//
// [EOF]
//
