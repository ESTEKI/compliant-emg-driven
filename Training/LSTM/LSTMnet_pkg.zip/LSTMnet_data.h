//
// File: LSTMnet_data.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Sep-2021 16:49:07
//

#ifndef LSTMNET_DATA_H
#define LSTMNET_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern boolean_T isInitialized_LSTMnet;

#endif
//
// File trailer for LSTMnet_data.h
//
// [EOF]
//
