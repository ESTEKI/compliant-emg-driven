//
// File: LSTMnet_terminate.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Sep-2021 16:49:07
//

#ifndef LSTMNET_TERMINATE_H
#define LSTMNET_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void LSTMnet_terminate();

#endif
//
// File trailer for LSTMnet_terminate.h
//
// [EOF]
//
