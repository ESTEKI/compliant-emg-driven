//
// File: LSTMnet.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Sep-2021 16:49:07
//

#ifndef LSTMNET_H
#define LSTMNET_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern float LSTMnet(const double x[3]);

void LSTMnet_init();

#endif
//
// File trailer for LSTMnet.h
//
// [EOF]
//
