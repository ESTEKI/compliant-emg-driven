//
// File: LSTMnet_data.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Sep-2021 16:49:07
//

// Include Files
#include "LSTMnet_data.h"

// Variable Definitions
boolean_T isInitialized_LSTMnet = false;

//
// File trailer for LSTMnet_data.cpp
//
// [EOF]
//
