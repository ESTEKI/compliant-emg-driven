//
// File: LSTMnet_types.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Sep-2021 16:49:07
//

#ifndef LSTMNET_TYPES_H
#define LSTMNET_TYPES_H

// Include Files
#include "rtwtypes.h"

#endif
//
// File trailer for LSTMnet_types.h
//
// [EOF]
//
