//
// File: LSTMnet_terminate.cpp
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Sep-2021 16:49:07
//

// Include Files
#include "LSTMnet_terminate.h"
#include "LSTMnet_data.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void LSTMnet_terminate()
{
  // (no terminate code required)
  isInitialized_LSTMnet = false;
}

//
// File trailer for LSTMnet_terminate.cpp
//
// [EOF]
//
