//
// File: predict.h
//
// MATLAB Coder version            : 5.2
// C/C++ source code generated on  : 26-Sep-2021 16:49:07
//

#ifndef PREDICT_H
#define PREDICT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
class net2lstm_miladch235_netWork0_0;

// Function Declarations
namespace coder {
float DeepLearningNetwork_predict(net2lstm_miladch235_netWork0_0 *obj,
                                  const double varargin_1[3]);

}

#endif
//
// File trailer for predict.h
//
// [EOF]
//
